@extends('layouts.app')

@section('title', $category->name . ' - بلاگ گروه باز')

@push('meta')
    <meta name="description" content="{{ $category->description ?? 'مقالات دسته‌بندی ' . $category->name }}">
    <meta property="og:title" content="{{ $category->name }} - بلاگ گروه باز">
    <meta property="og:description" content="{{ $category->description ?? 'مقالات دسته‌بندی ' . $category->name }}">
    <link rel="canonical" href="{{ route('blog.category', $category->slug) }}">
@endpush

@section('content')
<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('home') }}" class="text-decoration-none">خانه</a></li>
            <li class="breadcrumb-item"><a href="{{ route('blog.index') }}" class="text-decoration-none">بلاگ</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ $category->name }}</li>
        </ol>
    </nav>

    <!-- Category Header -->
    <div class="glass-card p-4 p-md-5 mb-5 text-center">
        <div class="category-icon mx-auto mb-3" style="width: 100px; height: 100px; font-size: 3rem;">
            <i class="bi {{ $category->icon ?? 'bi-grid-3x3-gap' }}"></i>
        </div>
        <h1 class="display-5 mb-3 text-white">{{ $category->name }}</h1>
        @if($category->description)
        <p class="lead text-white-50">{{ $category->description }}</p>
        @endif
        <p class="text-white-50 mb-0">
            <i class="bi bi-file-text me-1"></i>
            {{ $posts->total() }} مقاله
        </p>
    </div>

    <!-- Posts Grid -->
    <div class="row g-4">
        @forelse($posts as $post)
        <div class="col-md-6 col-lg-4">
            <div class="glass-card h-100">
                @if($post->banner_image)
                <a href="{{ route('blog.post', $post->slug) }}">
                    <img src="{{ asset($post->banner_image) }}" alt="{{ $post->title }}" class="w-100" style="height: 200px; object-fit: cover; border-radius: 20px 20px 0 0;">
                </a>
                @endif
                <div class="p-4">
                    <h5 class="mb-3">
                        <a href="{{ route('blog.post', $post->slug) }}" class="text-white text-decoration-none">
                            {{ $post->title }}
                        </a>
                    </h5>
                    <p class="text-white-50 small mb-3">{{ Str::limit($post->excerpt ?? strip_tags($post->content), 120) }}</p>
                    <div class="d-flex align-items-center justify-content-between text-white-50 small">
                        <span>
                            <i class="bi bi-person me-1"></i>
                            {{ $post->author->name }}
                        </span>
                        <span>
                            <i class="bi bi-calendar me-1"></i>
                            {{ $post->published_at->format('Y/m/d') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12">
            <div class="glass-card p-5 text-center">
                <i class="bi bi-inbox" style="font-size: 4rem; color: rgba(255,255,255,0.3);"></i>
                <p class="text-white-50 mt-3">هنوز مقاله‌ای در این دسته‌بندی منتشر نشده است.</p>
            </div>
        </div>
        @endforelse
    </div>

    <!-- Pagination -->
    @if($posts->hasPages())
    <div class="mt-5">
        {{ $posts->links('pagination::bootstrap-5') }}
    </div>
    @endif
</div>
@endsection

